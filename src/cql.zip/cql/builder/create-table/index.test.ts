import { cql } from "../../cql-types";
import { CreateTableBuilder } from "./builder";
import { withOptions } from "../../with-options";
import { expect, test } from "vitest";
import { CreateTableContext } from "./context";
import type { Client, types } from "cassandra-driver";

const mockClient = {
  async execute() {
    return undefined as unknown as Promise<types.ResultSet>;
  },
} as unknown as Client;

const example = CreateTableBuilder.create(mockClient)
  .table("user")
  .ifNotExists()
  .schema({
    id: cql.scalar.uuid,
    first_name: cql.scalar.text,
    last_name: cql.scalar.text,
    email: cql.scalar.text,
  })
  .primaryKey(["id", "email"], "first_name")
  .clusteringOrderBy({ first_name: "asc" })
  .with(
    withOptions.id("5a1c395e-b41f-11e5-9f22-ba0be0483c18"),
    withOptions.compactStorage(),
  );

test("Create table statement", () => {
  const cql = example.toCQL();

  expect(cql).toBe(
    "CREATE TABLE user IF NOT EXISTS (\nid UUID,\nfirst_name TEXT,\nlast_name TEXT,\nemail TEXT, PRIMARY KEY ( (id, email), first_name )\n) WITH CLUSTERING ORDER BY (first_name asc) AND ID = 5a1c395e-b41f-11e5-9f22-ba0be0483c18 AND COMPACT STORAGE;",
  );
});

test("Create table context", async () => {
  const context = example.build();

  expect(context).toBeInstanceOf(CreateTableContext);

  expect(context.toCQL()).toBe(
    "CREATE TABLE user IF NOT EXISTS (\nid UUID,\nfirst_name TEXT,\nlast_name TEXT,\nemail TEXT, PRIMARY KEY ( (id, email), first_name )\n) WITH CLUSTERING ORDER BY (first_name asc) AND ID = 5a1c395e-b41f-11e5-9f22-ba0be0483c18 AND COMPACT STORAGE;",
  );

  const result = await context.execute();

  expect(result).toBe(undefined); // Execute should return Promise<void>
});
