import { cql } from "../../cql-types";
import { withOptions } from "../../with-options";
import { test } from "vitest";
import type { Client, types } from "cassandra-driver";
import { CreateTableBuilder } from "../create-table/builder";

const mockClient = {
  async execute() {
    return undefined as unknown as Promise<types.ResultSet>;
  },
} as unknown as Client;

const userTable = CreateTableBuilder.create(mockClient)
  .table("user")
  .ifNotExists()
  .schema({
    id: cql.scalar.uuid,
    first_name: cql.scalar.text,
    last_name: cql.scalar.text,
    email: cql.scalar.text,
  })
  .primaryKey(["id", "email"], "first_name")
  .clusteringOrderBy({ first_name: "asc" })
  .with(
    withOptions.id("5a1c395e-b41f-11e5-9f22-ba0be0483c18"),
    withOptions.compactStorage(),
  )
  .build();

test("Select all statement", () => {
  const selectAll = userTable.select("*").build();
});

test("Create table context", async () => {});
